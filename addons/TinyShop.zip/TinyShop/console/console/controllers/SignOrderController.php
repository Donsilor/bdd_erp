<?php

namespace addons\TinyShop\console\controllers;

use Yii;
use yii\console\Controller;

/**
 * 自动签收订单
 *
 * Class SignOrderController
 * @package addons\TinyShop\console\controllers
 * @author jianyan74 <751393839@qq.com>
 */
class SignOrderController extends Controller
{
    public function actionRun()
    {

    }
}