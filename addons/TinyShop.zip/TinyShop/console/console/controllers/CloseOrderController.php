<?php

namespace addons\TinyShop\console\controllers;

use yii\console\Controller;

/**
 * 自动关闭订单
 *
 * Class CloseOrderController
 * @package addons\TinyShop\console\controllers
 * @author jianyan74 <751393839@qq.com>
 */
class CloseOrderController extends Controller
{
    public function actionRun()
    {

    }
}