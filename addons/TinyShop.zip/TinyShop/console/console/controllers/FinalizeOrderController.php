<?php

namespace addons\TinyShop\console\controllers;

use Yii;
use yii\console\Controller;

/**
 * 自动完成订单
 *
 * Class FinalizeOrderController
 * @package addons\TinyShop\console\controllers
 * @author jianyan74 <751393839@qq.com>
 */
class FinalizeOrderController extends Controller
{
    public function actionRun()
    {

    }
}