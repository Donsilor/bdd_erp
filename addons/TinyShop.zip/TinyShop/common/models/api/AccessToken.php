<?php

namespace addons\TinyShop\common\models\api;

/**
 * Class AccessToken
 * @package addons\TinyShop\common\models\api
 * @author jianyan74 <751393839@qq.com>
 */
class AccessToken extends \common\models\api\AccessToken
{

}