<?php

namespace addons\TinyShop\services\pickup;

use common\components\Service;
use addons\TinyShop\common\models\pickup\Auditor;

/**
 * Class AuditorService
 * @package addons\TinyShop\services\pickup
 * @author jianyan74 <751393839@qq.com>
 */
class AuditorService extends Service
{

}