<?php

echo '这是' . Yii::$app->params['addon']['name'] . ' backend 页面';