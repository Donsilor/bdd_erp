<?php

namespace addons\TinyShop\merchant\modules\order;

/**
 * Class Module
 * @package addons\TinyShop\merchant\modules\order
 * @author jianyan74 <751393839@qq.com>
 */
class Module extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'addons\TinyShop\merchant\modules\order\controllers';

    public function init()
    {
        parent::init();
    }
}