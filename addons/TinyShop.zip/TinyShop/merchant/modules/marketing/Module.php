<?php

namespace addons\TinyShop\merchant\modules\marketing;

/**
 * Class Module
 * @package addons\TinyShop\merchant\modules\marketing
 * @author jianyan74 <751393839@qq.com>
 */
class Module extends \yii\base\Module
{
    /**
     * {@inheritdoc}
     */
    public $controllerNamespace = 'addons\TinyShop\merchant\modules\marketing\controllers';

    public function init()
    {
        parent::init();
    }
}