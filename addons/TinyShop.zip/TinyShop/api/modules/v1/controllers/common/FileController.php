<?php

namespace addons\TinyShop\api\modules\v1\controllers\common;

/**
 * 文件上传
 *
 * Class FileController
 * @package addons\TinyShop\api\modules\v1\controllers\common
 * @author jianyan74 <751393839@qq.com>
 */
class FileController extends \api\modules\v1\controllers\FileController
{

}