<?php

namespace addons\TinyShop\api\modules\v1\controllers\member;

/**
 * Class AuthController
 * @package addons\TinyShop\api\modules\v1\controllers\member
 * @author jianyan74 <751393839@qq.com>
 */
class AuthController extends \api\modules\v1\controllers\member\AuthController
{

}