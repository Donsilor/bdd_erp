# CHANGELOG

## 1.1.1 - August 25, 2017
- Enh: Ported PHPUnit tests to Codeception (tonydspaniard)
- Enh: Remove Yii2 dependencies for all classes but those made for Yii2 (tonydspaniard)

## 1.1.0 - August 24, 2017
- Enh #18: Initial new release. Total refactor (tonydspaniard)
